
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;


public class GlobalData {
    public static String nameofuser ="abc";
    public static ArrayList<ExamQuestion> alq = new ArrayList<>();
    public static String categoryselected = "abc";
    public static String Photo = "";
    public static String Score = "";
    public static String Percentage = "";
}